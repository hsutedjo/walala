﻿namespace TH_W02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Play = new System.Windows.Forms.Button();
            this.lbl_Word1 = new System.Windows.Forms.Label();
            this.txtbox_Word1 = new System.Windows.Forms.TextBox();
            this.pnl_Word = new System.Windows.Forms.Panel();
            this.txtbox_Word2 = new System.Windows.Forms.TextBox();
            this.lbl_Word2 = new System.Windows.Forms.Label();
            this.txtbox_Word3 = new System.Windows.Forms.TextBox();
            this.lbl_Word3 = new System.Windows.Forms.Label();
            this.lbl_Word5 = new System.Windows.Forms.Label();
            this.txtbox_Word4 = new System.Windows.Forms.TextBox();
            this.txtbox_Word5 = new System.Windows.Forms.TextBox();
            this.lbl_Word4 = new System.Windows.Forms.Label();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.lbl_Huruf1 = new System.Windows.Forms.Label();
            this.lbl_Huruf5 = new System.Windows.Forms.Label();
            this.lbl_Huruf4 = new System.Windows.Forms.Label();
            this.lbl_Huruf3 = new System.Windows.Forms.Label();
            this.lbl_Huruf2 = new System.Windows.Forms.Label();
            this.lbl_Judul = new System.Windows.Forms.Label();
            this.lbl_Contekan = new System.Windows.Forms.Label();
            this.pnl_Play = new System.Windows.Forms.Panel();
            this.pnl_Word.SuspendLayout();
            this.pnl_Play.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(17, 162);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(75, 36);
            this.btn_Play.TabIndex = 0;
            this.btn_Play.Text = "Play";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // lbl_Word1
            // 
            this.lbl_Word1.AutoSize = true;
            this.lbl_Word1.Location = new System.Drawing.Point(14, 18);
            this.lbl_Word1.Name = "lbl_Word1";
            this.lbl_Word1.Size = new System.Drawing.Size(38, 13);
            this.lbl_Word1.TabIndex = 1;
            this.lbl_Word1.Text = "Kata 1";
            // 
            // txtbox_Word1
            // 
            this.txtbox_Word1.Location = new System.Drawing.Point(67, 15);
            this.txtbox_Word1.Name = "txtbox_Word1";
            this.txtbox_Word1.Size = new System.Drawing.Size(123, 20);
            this.txtbox_Word1.TabIndex = 2;
            // 
            // pnl_Word
            // 
            this.pnl_Word.Controls.Add(this.txtbox_Word2);
            this.pnl_Word.Controls.Add(this.btn_Play);
            this.pnl_Word.Controls.Add(this.lbl_Word2);
            this.pnl_Word.Controls.Add(this.lbl_Word1);
            this.pnl_Word.Controls.Add(this.txtbox_Word3);
            this.pnl_Word.Controls.Add(this.txtbox_Word1);
            this.pnl_Word.Controls.Add(this.lbl_Word3);
            this.pnl_Word.Controls.Add(this.lbl_Word5);
            this.pnl_Word.Controls.Add(this.txtbox_Word4);
            this.pnl_Word.Controls.Add(this.txtbox_Word5);
            this.pnl_Word.Controls.Add(this.lbl_Word4);
            this.pnl_Word.Location = new System.Drawing.Point(12, 12);
            this.pnl_Word.Name = "pnl_Word";
            this.pnl_Word.Size = new System.Drawing.Size(273, 245);
            this.pnl_Word.TabIndex = 3;
            // 
            // txtbox_Word2
            // 
            this.txtbox_Word2.Location = new System.Drawing.Point(67, 42);
            this.txtbox_Word2.Name = "txtbox_Word2";
            this.txtbox_Word2.Size = new System.Drawing.Size(123, 20);
            this.txtbox_Word2.TabIndex = 11;
            // 
            // lbl_Word2
            // 
            this.lbl_Word2.AutoSize = true;
            this.lbl_Word2.Location = new System.Drawing.Point(14, 45);
            this.lbl_Word2.Name = "lbl_Word2";
            this.lbl_Word2.Size = new System.Drawing.Size(38, 13);
            this.lbl_Word2.TabIndex = 10;
            this.lbl_Word2.Text = "Kata 2";
            // 
            // txtbox_Word3
            // 
            this.txtbox_Word3.Location = new System.Drawing.Point(67, 68);
            this.txtbox_Word3.Name = "txtbox_Word3";
            this.txtbox_Word3.Size = new System.Drawing.Size(123, 20);
            this.txtbox_Word3.TabIndex = 9;
            // 
            // lbl_Word3
            // 
            this.lbl_Word3.AutoSize = true;
            this.lbl_Word3.Location = new System.Drawing.Point(14, 71);
            this.lbl_Word3.Name = "lbl_Word3";
            this.lbl_Word3.Size = new System.Drawing.Size(38, 13);
            this.lbl_Word3.TabIndex = 8;
            this.lbl_Word3.Text = "Kata 3";
            // 
            // lbl_Word5
            // 
            this.lbl_Word5.AutoSize = true;
            this.lbl_Word5.Location = new System.Drawing.Point(14, 123);
            this.lbl_Word5.Name = "lbl_Word5";
            this.lbl_Word5.Size = new System.Drawing.Size(38, 13);
            this.lbl_Word5.TabIndex = 4;
            this.lbl_Word5.Text = "Kata 5";
            // 
            // txtbox_Word4
            // 
            this.txtbox_Word4.Location = new System.Drawing.Point(67, 94);
            this.txtbox_Word4.Name = "txtbox_Word4";
            this.txtbox_Word4.Size = new System.Drawing.Size(123, 20);
            this.txtbox_Word4.TabIndex = 7;
            // 
            // txtbox_Word5
            // 
            this.txtbox_Word5.Location = new System.Drawing.Point(67, 120);
            this.txtbox_Word5.Name = "txtbox_Word5";
            this.txtbox_Word5.Size = new System.Drawing.Size(123, 20);
            this.txtbox_Word5.TabIndex = 5;
            // 
            // lbl_Word4
            // 
            this.lbl_Word4.AutoSize = true;
            this.lbl_Word4.Location = new System.Drawing.Point(14, 97);
            this.lbl_Word4.Name = "lbl_Word4";
            this.lbl_Word4.Size = new System.Drawing.Size(38, 13);
            this.lbl_Word4.TabIndex = 6;
            this.lbl_Word4.Text = "Kata 4";
            // 
            // btn_Q
            // 
            this.btn_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q.Location = new System.Drawing.Point(108, 188);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(48, 44);
            this.btn_Q.TabIndex = 4;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Z.Location = new System.Drawing.Point(189, 288);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(48, 44);
            this.btn_Z.TabIndex = 5;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_W
            // 
            this.btn_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_W.Location = new System.Drawing.Point(162, 188);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(48, 44);
            this.btn_W.TabIndex = 6;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_L
            // 
            this.btn_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_L.Location = new System.Drawing.Point(567, 238);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(48, 44);
            this.btn_L.TabIndex = 8;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_K
            // 
            this.btn_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_K.Location = new System.Drawing.Point(513, 238);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(48, 44);
            this.btn_K.TabIndex = 9;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_J
            // 
            this.btn_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_J.Location = new System.Drawing.Point(459, 238);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(48, 44);
            this.btn_J.TabIndex = 10;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_H
            // 
            this.btn_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_H.Location = new System.Drawing.Point(405, 238);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(48, 44);
            this.btn_H.TabIndex = 11;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_G.Location = new System.Drawing.Point(351, 238);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(48, 44);
            this.btn_G.TabIndex = 12;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_F
            // 
            this.btn_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_F.Location = new System.Drawing.Point(297, 237);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(48, 44);
            this.btn_F.TabIndex = 13;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_D
            // 
            this.btn_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_D.Location = new System.Drawing.Point(243, 238);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(48, 44);
            this.btn_D.TabIndex = 14;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_S
            // 
            this.btn_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_S.Location = new System.Drawing.Point(189, 238);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(48, 44);
            this.btn_S.TabIndex = 15;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_A
            // 
            this.btn_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_A.Location = new System.Drawing.Point(135, 238);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(48, 44);
            this.btn_A.TabIndex = 16;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_P
            // 
            this.btn_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_P.Location = new System.Drawing.Point(594, 188);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(48, 44);
            this.btn_P.TabIndex = 17;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_O
            // 
            this.btn_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_O.Location = new System.Drawing.Point(540, 188);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(48, 44);
            this.btn_O.TabIndex = 18;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_I
            // 
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_I.Location = new System.Drawing.Point(486, 188);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(48, 44);
            this.btn_I.TabIndex = 19;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_U
            // 
            this.btn_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_U.Location = new System.Drawing.Point(432, 188);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(48, 44);
            this.btn_U.TabIndex = 20;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Y.Location = new System.Drawing.Point(378, 188);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(48, 44);
            this.btn_Y.TabIndex = 21;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_T
            // 
            this.btn_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_T.Location = new System.Drawing.Point(324, 188);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(48, 44);
            this.btn_T.TabIndex = 22;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_R
            // 
            this.btn_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_R.Location = new System.Drawing.Point(270, 188);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(48, 44);
            this.btn_R.TabIndex = 23;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_E
            // 
            this.btn_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_E.Location = new System.Drawing.Point(216, 188);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(48, 44);
            this.btn_E.TabIndex = 24;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_V
            // 
            this.btn_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_V.Location = new System.Drawing.Point(351, 288);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(48, 44);
            this.btn_V.TabIndex = 25;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_B
            // 
            this.btn_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_B.Location = new System.Drawing.Point(405, 288);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(48, 44);
            this.btn_B.TabIndex = 26;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_M
            // 
            this.btn_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_M.Location = new System.Drawing.Point(513, 288);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(48, 44);
            this.btn_M.TabIndex = 27;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_N
            // 
            this.btn_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_N.Location = new System.Drawing.Point(459, 288);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(48, 44);
            this.btn_N.TabIndex = 28;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_C
            // 
            this.btn_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_C.Location = new System.Drawing.Point(297, 288);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(48, 44);
            this.btn_C.TabIndex = 29;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_X
            // 
            this.btn_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_X.Location = new System.Drawing.Point(243, 288);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(48, 44);
            this.btn_X.TabIndex = 30;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // lbl_Huruf1
            // 
            this.lbl_Huruf1.AutoSize = true;
            this.lbl_Huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Huruf1.Location = new System.Drawing.Point(133, 106);
            this.lbl_Huruf1.Name = "lbl_Huruf1";
            this.lbl_Huruf1.Size = new System.Drawing.Size(93, 37);
            this.lbl_Huruf1.TabIndex = 31;
            this.lbl_Huruf1.Text = "____";
            // 
            // lbl_Huruf5
            // 
            this.lbl_Huruf5.AutoSize = true;
            this.lbl_Huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Huruf5.Location = new System.Drawing.Point(527, 106);
            this.lbl_Huruf5.Name = "lbl_Huruf5";
            this.lbl_Huruf5.Size = new System.Drawing.Size(93, 37);
            this.lbl_Huruf5.TabIndex = 32;
            this.lbl_Huruf5.Text = "____";
            // 
            // lbl_Huruf4
            // 
            this.lbl_Huruf4.AutoSize = true;
            this.lbl_Huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Huruf4.Location = new System.Drawing.Point(428, 106);
            this.lbl_Huruf4.Name = "lbl_Huruf4";
            this.lbl_Huruf4.Size = new System.Drawing.Size(93, 37);
            this.lbl_Huruf4.TabIndex = 33;
            this.lbl_Huruf4.Text = "____";
            // 
            // lbl_Huruf3
            // 
            this.lbl_Huruf3.AutoSize = true;
            this.lbl_Huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Huruf3.Location = new System.Drawing.Point(329, 106);
            this.lbl_Huruf3.Name = "lbl_Huruf3";
            this.lbl_Huruf3.Size = new System.Drawing.Size(93, 37);
            this.lbl_Huruf3.TabIndex = 34;
            this.lbl_Huruf3.Text = "____";
            // 
            // lbl_Huruf2
            // 
            this.lbl_Huruf2.AutoSize = true;
            this.lbl_Huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Huruf2.Location = new System.Drawing.Point(230, 106);
            this.lbl_Huruf2.Name = "lbl_Huruf2";
            this.lbl_Huruf2.Size = new System.Drawing.Size(93, 37);
            this.lbl_Huruf2.TabIndex = 35;
            this.lbl_Huruf2.Text = "____";
            // 
            // lbl_Judul
            // 
            this.lbl_Judul.AutoSize = true;
            this.lbl_Judul.Font = new System.Drawing.Font("Magneto", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Judul.Location = new System.Drawing.Point(216, 28);
            this.lbl_Judul.Name = "lbl_Judul";
            this.lbl_Judul.Size = new System.Drawing.Size(332, 45);
            this.lbl_Judul.TabIndex = 36;
            this.lbl_Judul.Text = "Guessing Game";
            // 
            // lbl_Contekan
            // 
            this.lbl_Contekan.AutoSize = true;
            this.lbl_Contekan.Location = new System.Drawing.Point(673, 38);
            this.lbl_Contekan.Name = "lbl_Contekan";
            this.lbl_Contekan.Size = new System.Drawing.Size(28, 13);
            this.lbl_Contekan.TabIndex = 37;
            this.lbl_Contekan.Text = "kata";
            // 
            // pnl_Play
            // 
            this.pnl_Play.Controls.Add(this.lbl_Huruf3);
            this.pnl_Play.Controls.Add(this.lbl_Contekan);
            this.pnl_Play.Controls.Add(this.btn_Q);
            this.pnl_Play.Controls.Add(this.lbl_Judul);
            this.pnl_Play.Controls.Add(this.btn_Z);
            this.pnl_Play.Controls.Add(this.lbl_Huruf2);
            this.pnl_Play.Controls.Add(this.btn_W);
            this.pnl_Play.Controls.Add(this.btn_L);
            this.pnl_Play.Controls.Add(this.lbl_Huruf4);
            this.pnl_Play.Controls.Add(this.btn_K);
            this.pnl_Play.Controls.Add(this.lbl_Huruf5);
            this.pnl_Play.Controls.Add(this.btn_J);
            this.pnl_Play.Controls.Add(this.lbl_Huruf1);
            this.pnl_Play.Controls.Add(this.btn_H);
            this.pnl_Play.Controls.Add(this.btn_X);
            this.pnl_Play.Controls.Add(this.btn_G);
            this.pnl_Play.Controls.Add(this.btn_C);
            this.pnl_Play.Controls.Add(this.btn_F);
            this.pnl_Play.Controls.Add(this.btn_N);
            this.pnl_Play.Controls.Add(this.btn_D);
            this.pnl_Play.Controls.Add(this.btn_M);
            this.pnl_Play.Controls.Add(this.btn_S);
            this.pnl_Play.Controls.Add(this.btn_B);
            this.pnl_Play.Controls.Add(this.btn_A);
            this.pnl_Play.Controls.Add(this.btn_V);
            this.pnl_Play.Controls.Add(this.btn_P);
            this.pnl_Play.Controls.Add(this.btn_E);
            this.pnl_Play.Controls.Add(this.btn_O);
            this.pnl_Play.Controls.Add(this.btn_R);
            this.pnl_Play.Controls.Add(this.btn_I);
            this.pnl_Play.Controls.Add(this.btn_T);
            this.pnl_Play.Controls.Add(this.btn_U);
            this.pnl_Play.Controls.Add(this.btn_Y);
            this.pnl_Play.Location = new System.Drawing.Point(12, 12);
            this.pnl_Play.Name = "pnl_Play";
            this.pnl_Play.Size = new System.Drawing.Size(769, 364);
            this.pnl_Play.TabIndex = 38;
            this.pnl_Play.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_Play);
            this.Controls.Add(this.pnl_Word);
            this.Name = "Form1";
            this.Text = "Guessing Game";
            this.pnl_Word.ResumeLayout(false);
            this.pnl_Word.PerformLayout();
            this.pnl_Play.ResumeLayout(false);
            this.pnl_Play.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Play;
        private System.Windows.Forms.Label lbl_Word1;
        private System.Windows.Forms.TextBox txtbox_Word1;
        private System.Windows.Forms.Panel pnl_Word;
        private System.Windows.Forms.TextBox txtbox_Word5;
        private System.Windows.Forms.Label lbl_Word5;
        private System.Windows.Forms.TextBox txtbox_Word4;
        private System.Windows.Forms.Label lbl_Word4;
        private System.Windows.Forms.TextBox txtbox_Word3;
        private System.Windows.Forms.Label lbl_Word3;
        private System.Windows.Forms.TextBox txtbox_Word2;
        private System.Windows.Forms.Label lbl_Word2;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Label lbl_Huruf1;
        private System.Windows.Forms.Label lbl_Huruf5;
        private System.Windows.Forms.Label lbl_Huruf4;
        private System.Windows.Forms.Label lbl_Huruf3;
        private System.Windows.Forms.Label lbl_Huruf2;
        private System.Windows.Forms.Label lbl_Judul;
        private System.Windows.Forms.Label lbl_Contekan;
        private System.Windows.Forms.Panel pnl_Play;
    }
}

