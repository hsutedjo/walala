﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_W02
{
    public partial class Form1 : Form
    {
        string kataTerpilih;
        List<string> kata = new List<string>();
        List<Label> lbls = new List<Label>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            if (txtbox_Word1.TextLength != 5 || txtbox_Word2.TextLength != 5 || txtbox_Word3.TextLength != 5 || txtbox_Word4.TextLength != 5 || txtbox_Word5.TextLength != 5 || txtbox_Word1.Text == txtbox_Word2.Text || txtbox_Word1.Text == txtbox_Word3.Text || txtbox_Word1.Text == txtbox_Word4.Text || txtbox_Word1.Text == txtbox_Word5.Text || txtbox_Word2.Text == txtbox_Word3.Text || txtbox_Word2.Text == txtbox_Word4.Text || txtbox_Word2.Text == txtbox_Word5.Text || txtbox_Word3.Text == txtbox_Word4.Text || txtbox_Word3.Text == txtbox_Word5.Text || txtbox_Word4.Text == txtbox_Word5.Text)
            {
                MessageBox.Show("Input Invalid, Please Fix");
            }
            else
            {
                pnl_Word.Visible = false;
                pnl_Play.Visible = true;
                Random rnd = new Random();
                kata.AddRange (new string[] { txtbox_Word1.Text, txtbox_Word2.Text, txtbox_Word3.Text, txtbox_Word4.Text, txtbox_Word5.Text});
                int rndKata = rnd.Next(0, 5);
                kataTerpilih = kata[rndKata].ToUpper();
                lbl_Contekan.Text = kataTerpilih;
                lbls.AddRange (new Label[]{lbl_Huruf1, lbl_Huruf2, lbl_Huruf3, lbl_Huruf4, lbl_Huruf5});
            }
        }
        private void btn_H_Click(object sender, EventArgs e)
        {
            Button btn = (Button) sender;
            int gaKetebak = 0;
            for (int i = 0; i <= 4; i++)
            {
                if (btn.Text == kataTerpilih[i].ToString())
                {
                    lbls[i].Text = kataTerpilih[i].ToString();
                }
            }
            foreach (Label lbl in lbls)
            {
                if (lbl.Text == "____")
                {
                    gaKetebak++;
                }
            }
            if (gaKetebak == 0)
            {
                MessageBox.Show("Congrats! You Win!");
            }

        }
    }
}
